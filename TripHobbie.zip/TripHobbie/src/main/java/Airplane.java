public class Airplane extends Transport{

    private int idAirplane;
    private static int airplaneCounter;

    public Airplane(String transportType, double price, boolean availability){
        super(transportType, price, availability);
        this.idAirplane =++Airplane.airplaneCounter;
    }

    @Override
    public String toString() {
       return "Airplane{"+ "idAirplane =" + idAirplane+ ", " + super.toString() + '}';
    }
}
