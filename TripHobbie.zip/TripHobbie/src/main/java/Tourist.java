import java.util.Arrays;

public class Tourist {

    private int idTourist;
    private Trip trips [];
    private static int touristCounter;
    private int tripsCounter;
    private static final int MAX_TRIPS = 10;

    public Tourist(){
        this.idTourist = ++Tourist.touristCounter;
        this.trips = new Trip[Tourist.MAX_TRIPS];
    }

    public void addTrip(Trip trip){
        if (this.tripsCounter<Tourist.MAX_TRIPS){
            this.trips[this.tripsCounter++] = trip;
        }
        else{
            System.out.println("the maximum number of Trips has been exceeded");
        }
    }

    public double totalPriceTrip (){
        double total=0;
        for (int i = 0; i < this.tripsCounter; i++){
            Trip trip = this.trips[i];
            total += trip.getPriceTrip();
        }
        return total;
    }

    public void displayTrip(){
        System.out.println("Trip: " + this.idTourist);
        double totalTrips = this.totalPriceTrip();
        System.out.println("Total price of Trip for the tourist: $ "+ totalPriceTrip());
        System.out.println("trips that will be done for the tourist: ");
        for (int i=0; i<this.tripsCounter;i++){
            System.out.println(this.trips[i]);
        }
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Tourist{");
        sb.append(", trips=").append(Arrays.toString(trips));
        sb.append('}');
        return sb.toString();
    }
}
