public class Hotel {
    private int idHotel;
    private String hotelName;
    private boolean roomAvailability;
    private double roomPrice;
    private static int hotelCounter;

    private Hotel(){
        this.idHotel = ++Hotel.hotelCounter;
    }

    public Hotel( String hotelName, boolean roomAvailability, double roomPrice) {

        this.hotelName = hotelName;
        this.roomAvailability = roomAvailability;
        this.roomPrice = roomPrice;
    }

    public int getIdHotel() {
        return this.idHotel;
    }

    public String getHotelName() {
        return this.hotelName;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }

    public boolean isRoomAvailability() {
        return this.roomAvailability;
    }

    public void setRoomAvailability(boolean roomAvailability) {
        this.roomAvailability = roomAvailability;
    }

    public double getRoomPrice() {
        return this.roomPrice;
    }

    public void setRoomPrice(double roomPrice) {
        this.roomPrice = roomPrice;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Hotel{");
        sb.append(", hotelName='").append(hotelName).append('\'');
        sb.append(", roomAvailability=").append(roomAvailability);
        sb.append(", roomPrice=").append(roomPrice);
        sb.append('}');
        return sb.toString();
    }
}

