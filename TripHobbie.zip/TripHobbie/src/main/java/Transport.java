public class Transport {

    private String transportType;
    private double price;
    private boolean availability;

    public Transport(String transportType, double price, boolean availability) {
        this.transportType = transportType;
        this.availability = availability;
        this.price = price;
    }

    public String getTransportType() {
        return this.transportType;
    }

    public void setTransportType(String transportType) {
        this.transportType = transportType;
    }

    public double getPrice() {
        return this.price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Transport{");
        sb.append("transportType='").append(transportType).append('\'');
        sb.append(", price=").append(price);
        sb.append('}');
        return sb.toString();
    }
}
