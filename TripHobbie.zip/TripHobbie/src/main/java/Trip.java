import java.util.Date;

public class Trip {

    private int idTrip;
    private String country;
    private String city;
    private double priceTrip;
    private Hotel hotel;
    private Transport transport;
    private Destination destination;
    private static int tripCounter;

    private Trip() {
        this.idTrip = ++Trip.tripCounter;
    }

    public Trip( String country, String city, Hotel hotel, Transport transport, Destination destination) {
        this();
        this.country = country;
        this.city = city;
        this.hotel = hotel;
        this.transport = transport;
        this.destination = destination;
    }

    public int getIdTrip() {
        return this.idTrip;
    }

    public String getCountry() {
        return this.country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return this.city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public double getPriceTrip(){
        priceTrip = hotel.getRoomPrice() + transport.getPrice()+ destination.totalPrice();
        return this.priceTrip;
    }

    public Hotel getHotel() {
        return this.hotel;
    }

    public void setHotel(Hotel hotel) {
        this.hotel = hotel;
    }

    public Transport getTransport() {
        return this.transport;
    }

    public void setTransport(Transport transport) {
        this.transport = transport;
    }

    public Destination getDestination() {
        return this.destination;
    }

    public void setDestination(Destination destination) {
        this.destination = destination;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Trip{");
        sb.append("idTrip=").append(idTrip);
        sb.append(", country='").append(country).append('\'');
        sb.append(", city='").append(city).append('\'');
        sb.append(", hotel=").append(hotel);
        sb.append(", transport=").append(transport);
        sb.append(", destination=").append(destination);
        sb.append('}');
        return sb.toString();
    }
}


