public class Destination {

    private final int idDestination;
    private Activity activities[];
    private int activitiesCounter;
    private static int destinationCounter;
    private static final int MAX_ACTIVITIES = 10;

    public Destination(){
        this.idDestination = ++Destination.destinationCounter;
        this.activities = new Activity[Destination.MAX_ACTIVITIES];
    }

    public  void addActivity(Activity activity){
        if(this.activitiesCounter < Destination.MAX_ACTIVITIES){
            this.activities[this.activitiesCounter++] = activity;
        }
        else{
            System.out.println("The maximum number of activities per trip has been exceeded"+ Destination.MAX_ACTIVITIES);
        }
    }

    public double totalPrice(){
        double total =0;
        for (int i =0; i< this.activitiesCounter;i++){
            Activity activity = this.activities[i];
            total += activity.getPrice();
        }
        return total;
    }

    public void displayDestination (){
        System.out.println("Id Destination: "+ this.idDestination);
        double totalDestination= this.totalPrice();
        System.out.println("Total Price of activities in the destiny: $ "+totalPrice());
        System.out.println("Activities that will be done in the destination: ");
        for (int i=0; i< this.activitiesCounter;i++){
            System.out.println(this.activities[i]);
        }
    }

}
