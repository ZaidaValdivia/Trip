public class Main {

    public static void main(String[] args) {

        Activity activity1 = new Activity("Trecking", 50.0);
        Activity activity2 = new Activity("Kayak", 100.0);
        Activity activity3 = new Activity("Rappel", 60.0);
        Activity activity4 = new Activity("Horse ride", 70.0);
        Activity activity5 = new Activity("Swimming with dolphins", 200.0);
        Activity activity6 = new Activity("paragliding", 150.0);
        Activity activity7 = new Activity("Helicopter tour", 300.0);
        Activity activity8 = new Activity("City tour", 50.0);
        Activity activity9 = new Activity("Museums visit", 100.0);
        Activity activity10 = new Activity("Thematic parks", 200.0);

        Destination destination1 = new Destination();
        destination1.addActivity(activity1);
        destination1.addActivity(activity5);
        destination1.addActivity(activity7);
        destination1.addActivity(activity8);
        destination1.addActivity(activity9);
        destination1.addActivity(activity10);

        Hotel hotel1 = new Hotel("Radisson Hotel", true, 900.00);
        Transport transport1 = new Transport("Airplane", 600.00, true);
        Trip trip1 = new Trip("EEUU", "Miami", hotel1, transport1, destination1);
        Tourist tourist1 = new Tourist();
        tourist1.addTrip(trip1);
        tourist1.totalPriceTrip();
        tourist1. displayTrip();
        destination1.displayDestination();




    }
}
