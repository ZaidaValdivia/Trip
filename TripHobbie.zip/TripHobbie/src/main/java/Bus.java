public class Bus extends Transport {

    private int idBus;
    private static int busCounter;

    public Bus (String transportType, double price, boolean availability){
        super(transportType, price, availability);
        this.idBus = ++Bus.busCounter;
    }

    @Override
    public String toString() {
        return "Bus{" + "idBus =" + idBus+ ", " +super.toString()+ '}';
    }
}

