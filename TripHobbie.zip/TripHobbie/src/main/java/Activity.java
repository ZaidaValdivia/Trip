public class Activity {

    private final int idActivity;
    private String name;
    private double price;
    private static int activityCounter;

    private Activity() {
        this.idActivity = ++Activity.activityCounter;
    }

    public Activity(String name, double price) {
        this();
        this.name = name;
        this.price = price;
    }

    public int getIdActivity() {
        return this.idActivity;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return this.price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Activity{");
        sb.append("idActivity=").append(idActivity);
        sb.append(", name='").append(name).append('\'');
        sb.append(", price=").append(price);
        sb.append('}');
        return sb.toString();
    }
}
